class Main 
{
  public static void main(String[] args) 
  {
    System.out.println("Hello mars!");
    System.out.println("Hello Mom");
    System.out.println("hi there");
  }
}